# flake8: noqa

from ._package import PackageInfo
"""Models utilized in uploading packages to feeds."""

import os
from typing import Optional

from pydantic import BaseModel, field_validator

from nisystemlink_feeds_manager.constants import UserMessages
from nisystemlink_feeds_manager.helpers import InvalidPackageFileError


class PackageInfo(BaseModel):
    """Package Information."""

    feed_name: str
    path: str
    overwrite: Optional[bool] = False

    @field_validator("path")
    @classmethod
    def validate_package_path(cls, path: str) -> str:
        """Validator to validate the package file path.

        Args:
            path (str): File Path of the measurement package.

        Returns:
            str: Package file path.
        """
        if not os.path.exists(path):
            raise FileNotFoundError(UserMessages.INVALID_PACKAGE_PATH.format(path=path))

        file_extension = os.path.splitext(path)[1]
        file_name = os.path.basename(path)

        if file_extension not in [".nipkg", ".deb", ".ipk"]:
            raise InvalidPackageFileError(UserMessages.INVALID_PACKAGE_FILE.format(file=file_name))

        return path

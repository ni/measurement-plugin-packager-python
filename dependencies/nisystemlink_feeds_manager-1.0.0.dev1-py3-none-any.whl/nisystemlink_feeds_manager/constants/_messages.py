"""Constants utilized in User facing console messages."""

NIPKG = ".nipkg"
DEB = ".deb"
IPK = ".ipk"
SUPPORTED_PACKAGE_TYPES = [NIPKG, DEB, IPK]


class UserMessages:
    """User messages."""

    INVALID_PACKAGE_FILE = "Invalid package file - '{file}', Valid extensions are\
 .nipkg, .deb, .ipk"
    INVALID_PACKAGE_PATH = "Invalid package path - '{path}' provided,\
 Please provide the valid path."
    NO_GRAINS_FILE = "Grains file not found at '{path}'. Please try reconnecting the system to\
 SystemLink using SystemLink Client."
    NO_WORKSPACE_ID = "Workspace ID is not available in Grains file - '{path}'.\
 Please try reconnecting the system to SystemLink using SystemLink Client. "
    INVALID_WORKSPACE = "Workspace '{name}' not accessable for your SystemLink credentials,\
 Please enter the valid workspace name."

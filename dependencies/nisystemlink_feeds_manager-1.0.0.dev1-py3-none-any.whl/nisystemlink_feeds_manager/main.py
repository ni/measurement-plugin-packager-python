"""Publish Packages to SystemLink Feeds."""

import os

from nisystemlink_feeds_manager.clients.core import HttpConfiguration, JupyterHttpConfiguration
from nisystemlink_feeds_manager.clients.feeds._apis import SystemLinkFeedsClient
from nisystemlink_feeds_manager.clients.feeds.models import (
    CreateFeedRequest,
    Platform,
    UploadPackageResponse,
)
from nisystemlink_feeds_manager.constants import NIPKG, WorkSpaceIDPath, UserMessages
from nisystemlink_feeds_manager.helpers import get_system_workspace, get_workspace_id_from_name
from nisystemlink_feeds_manager.models import PackageInfo


class PublishPackagesToSystemLink:
    """Class contains a set of methods for publishing packages to SystemLink Feeds."""

    def __init__(
        self,
        server_url: str = None,
        server_api_key: str = None,
        workspace_name: str = None,
    ):
        """Initialize an instance.

        If any of the arguments is not provided, then the `SystemLink Client` Configuration will be utilized. # noqa: W505
        API key from systemlink client configuration doesn't not have the permission to write in `Feeds services`. # noqa: W505
        So the API key has to be created from systemlink web server manually.

        Args:
            server_url (str, optional): Systemlink API URL. Defaults to None.
            server_api_key (str, optional): Systemlink API Key. Defaults to None.
            workspace_name (str, optional): Workspace name. Defaults to None.
        """
        systemlink_config = JupyterHttpConfiguration()

        if not server_url:
            server_url = systemlink_config.server_uri

        if server_url and server_api_key:
            self.client = SystemLinkFeedsClient(
                configuration=HttpConfiguration(
                    server_uri=server_url,
                    api_key=server_api_key,
                )
            )
        else:
            self.client = SystemLinkFeedsClient()

        if not workspace_name:
            self.workspace_id = get_system_workspace()
        else:
            self.workspace_id = get_workspace_id_from_name(
                name=workspace_name,
                api_key=server_api_key,
                server_url=server_url,
            )

        if not self.workspace_id:
            raise ValueError(
                UserMessages.NO_WORKSPACE_ID.format(
                    path=WorkSpaceIDPath.SL_CLIENT_GRAIN_FILE_PATH
                )
            )

    def __get_feed_platform(self, package_path: str) -> str:
        _, pkg_ext = os.path.splitext(package_path)

        if pkg_ext == NIPKG:
            return Platform.WINDOWS.value

        return Platform.NI_LINUX_RT.value

    def upload_package(self, package_info: PackageInfo) -> UploadPackageResponse:
        """Upload package to `SystemLink` feeds.

        Args:
            package_info (PackageInfo): Information about the package to be uploaded.

        Returns:
            UploadPackageResponse: Upload package response.
        """
        platform = self.__get_feed_platform(package_info.path)
        query_feeds = self.client.query_feeds(
            platform=platform,
            workspace=self.workspace_id,
        )
        existing_feeds = {}
        for feed in query_feeds.feeds:
            existing_feeds[feed.name] = feed.id

        if package_info.feed_name not in existing_feeds:
            create_feed_request = CreateFeedRequest(
                name=package_info.feed_name,
                workspace=self.workspace_id,
                platform=platform,
            )
            created_feed = self.client.create_feed(create_feed_request)
            feed_id = created_feed.id
        else:
            feed_id = existing_feeds[package_info.feed_name]

        package_name = os.path.basename(package_info.path)
        upload_response = self.client.upload_package(
            feed_id=feed_id,
            package=(package_name, open(package_info.path, "rb"), "multipart/form-data"),
            overwrite=package_info.overwrite,
        )

        return upload_response

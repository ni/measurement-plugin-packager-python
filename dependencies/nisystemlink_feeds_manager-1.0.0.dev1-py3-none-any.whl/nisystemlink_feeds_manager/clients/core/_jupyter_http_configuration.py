# -*- coding: utf-8 -*-
# flake8: noqa

"""Implementation of JupyterHttpConfiguration."""

import json

from nisystemlink_feeds_manager.clients import core


class JupyterHttpConfiguration(core.HttpConfiguration):
    """An :class:`HttpConfiguration` for Jupyter notebooks running in a SystemLink environment."""

    _HTTP_MASTER_JSON_PATH = "C:\\ProgramData\\National Instruments\\Skyline\\HttpConfigurations\\http_master.json"
    _HTTP_URI_VAR = "Uri"
    _HTTP_API_KEY_VAR = "ApiKey"

    def __init__(self) -> None:
        """Initialize a configuration for SystemLink using API key-based
        authentication provided through environment variables.

        Raises:
            FileNotFoundError: if the `http_master.json` file not found in the specified path.
            KeyError: If `http_master.json` doesn't have the key `ApiKey`.
        """
        with open(self._HTTP_MASTER_JSON_PATH, "r") as fp:
            data = json.load(fp)

        server_url = data[self._HTTP_URI_VAR]
        api_key = data[self._HTTP_API_KEY_VAR]

        super().__init__(server_url, api_key)

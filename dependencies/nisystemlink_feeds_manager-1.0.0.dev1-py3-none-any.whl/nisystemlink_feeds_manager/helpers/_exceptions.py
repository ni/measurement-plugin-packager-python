"""Custom exceptions for `NISystemLink Feeds Manager` Package."""


class InvalidPackageFileError(Exception):
    """Custom exception for any invalid package file."""

    def __init__(self, message):
        """Initialize exception.

        Args:
            message (str): The message to be displayed.
        """
        self.message = message
        super().__init__(self.message)


class InvalidWorkspaceError(Exception):
    """Custom exception for any unauthorized workspace."""

    def __init__(self, message):
        """Initialize exception.

        Args:
            message (str): The message to be displayed.
        """
        self.message = message
        super().__init__(self.message)

"""Retrieve Workspace ID from `SystemLink Client Grain File`."""

from typing import Dict

import yaml

from nisystemlink_feeds_manager.clients.auth import AuthClient
from nisystemlink_feeds_manager.clients.core import HttpConfiguration, JupyterHttpConfiguration
from nisystemlink_feeds_manager.constants import (
    SYSTEMLINK_WORKSPACE,
    UserMessages,
    WorkSpaceIDPath,
)
from nisystemlink_feeds_manager.helpers import InvalidWorkspaceError


def get_system_workspace() -> str:
    """Get the workspace of the connected remote system.

    Read workspace from `grains` file of SystemLink Client.

    Raises:
        KeyError: If the `grains` file don't have the `systemlink_workspace` key.
        FileNotFoundError: If the `grains` not found in the specified path.

    Returns:
        str: Workspace Id of the system.
    """
    try:
        with open(WorkSpaceIDPath.SL_CLIENT_GRAIN_FILE_PATH, "r") as fp:
            grain_data: Dict = yaml.safe_load(fp)

        return grain_data.get(SYSTEMLINK_WORKSPACE)

    except FileNotFoundError as exp:
        raise FileNotFoundError(
            UserMessages.NO_GRAINS_FILE.format(path=WorkSpaceIDPath.SL_CLIENT_GRAIN_FILE_PATH)
        ) from exp

    except KeyError as exp:
        raise KeyError(
            UserMessages.NO_WORKSPACE_ID.format(path=WorkSpaceIDPath.SL_CLIENT_GRAIN_FILE_PATH)
        ) from exp


def get_workspace_id_from_name(name: str, api_key: str, server_url: str) -> str:
    """Get workspace id from provided workspace name.

    Args:
        name (str): Workspace name.
        api_key (str): Systemlink API Key.
        server_url (str): Systemlink URL.

    Raises:
        InvalidWorkspaceError: If the workspace not accessable for the provided\
 SystemLink credentials.

    Returns:
        str: ID of the workspace.
    """
    systemlink_config = JupyterHttpConfiguration()

    if not server_url:
        server_url = systemlink_config.server_uri or server_url

    if api_key and server_url:
        auth_client = AuthClient(HttpConfiguration(server_uri=server_url, api_key=api_key))
    else:
        auth_client = AuthClient()

    caller_info = auth_client.authenticate()
    workspaces_info = caller_info.workspaces

    for workspace_info in workspaces_info:
        if workspace_info.name == name:
            return workspace_info.id

    raise InvalidWorkspaceError(UserMessages.INVALID_WORKSPACE.format(name=name))
